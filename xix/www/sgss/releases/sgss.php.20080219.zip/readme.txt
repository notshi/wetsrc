SIMPLE GAMES SITE SCRIPT
------------------------


Required
--------
A web host, that supports php
The files, that are distributed with this file that you are reading.


Aditional
---------
The ability to edit these simple php scripts into something that you like :)


How?
----

Edit these files to your liking.

game.php is single game display

games.php is the games list display

games.css you like css right?

swfobject.js The wonderful swfobject code -> http://blog.deconcept.com/swfobject/

admin.php sets everything up, you should run it occasionally to get new games.

At the very least you should change the password in admin.php

The default settings are

name: admin
password: secret

You probably want to change that, it's right at the top of the file...

upload these files (the files you got with this file) to somewhere on your server (you need a server remember)

open the admin.php in a web browser, it will require a user and password to run

they are set to admin and secret by default

this will create a games subdirectory and read the mochi games feed for new games creating lots of files within it

this may take some time

wait for it to finish

you may now visit games.php on your site and play any games you see

you are free to hack these scripts around as you like

In fact I sugest you do it now

but remember

there is no support!!!!1111oneoneone

If things go bad, you are on your own :)


Kriss



(C) Kriss Daniels 2008 http://www.XIXs.com

This file made available under the terms of The MIT License : http://www.opensource.org/licenses/mit-license.php

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

